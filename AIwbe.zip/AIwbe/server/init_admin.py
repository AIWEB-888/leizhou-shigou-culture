from werkzeug.security import generate_password_hash
import pymysql

# 数据库连接信息
config = {
    'host': 'localhost',
    'user': 'root',
    'password': 'Hjshzhz110',
    'database': 'shigou_db',
    'cursorclass': pymysql.cursors.DictCursor
}

try:
    # 连接数据库
    conn = pymysql.connect(**config)
    cursor = conn.cursor()
    
    # 检查users表是否有is_admin字段
    cursor.execute("SHOW COLUMNS FROM users LIKE 'is_admin'")
    result = cursor.fetchone()
    
    if not result:
        # 添加is_admin字段
        cursor.execute("ALTER TABLE users ADD COLUMN is_admin TINYINT(1) DEFAULT 0")
        print("已添加is_admin字段")
    
    # 检查管理员用户是否已存在
    cursor.execute("SELECT id FROM users WHERE username = 'admin'")
    admin = cursor.fetchone()
    
    if not admin:
        # 创建管理员用户
        hashed_password = generate_password_hash('admin123')
        cursor.execute(
            "INSERT INTO users (username, email, password, nickname, is_admin) VALUES (%s, %s, %s, %s, %s)",
            ('admin', 'admin@example.com', hashed_password, '管理员', 1)
        )
        conn.commit()
        print("管理员用户创建成功")
    else:
        # 更新现有管理员用户的is_admin字段
        cursor.execute("UPDATE users SET is_admin = 1 WHERE username = 'admin'")
        conn.commit()
        print("管理员用户已存在，已更新权限")
    
    cursor.close()
    conn.close()
    print("初始化完成")
    
except Exception as e:
    print(f"错误: {str(e)}")
