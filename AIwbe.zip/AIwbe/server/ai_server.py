import hashlib
import hmac
import json
import time
import os
import secrets
from datetime import datetime, timedelta
from urllib.parse import quote
import requests
from flask import Flask, request, jsonify, session
from flask_cors import CORS
from flask_mysqldb import MySQL
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = 'shigou_secret_key_2024'

CORS(app, supports_credentials=True, origins=['http://localhost:8000', 'http://127.0.0.1:8000'])

app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = 'Hjshzhz110'
app.config['MYSQL_DB'] = 'shigou_db'
app.config['MYSQL_CURSORCLASS'] = 'DictCursor'

mysql = MySQL(app)

user_tokens = {}

def get_current_user_id():
    token = request.headers.get('Authorization', '').replace('Bearer ', '')
    if token and token in user_tokens:
        return user_tokens[token]
    if 'user_id' in session:
        return session['user_id']
    return None

ACCESS_KEY_ID = "AKLTYWMwMDA2YTlkZTQ1NDk2MWEzZjYzYjE1NTg5MzAxYjY"
SECRET_ACCESS_KEY = "WkRrd1pqbGhZekZpTURsaU5HRTJPV0l3WkRFNVl6aGlaR1U0WWpReU9UWQ=="

ARK_API_KEY = "cce8b0d2-6b92-41ca-8d1f-0ea5fffd36b0"
ARK_MODEL_ID = "ep-m-20260313104555-brgnz"

API_URL = "https://visual.volcengineapi.com"
REGION = "cn-north-1"
SERVICE = "cv"
VERSION = "2022-08-31"

def sha256_hash(data):
    if isinstance(data, str):
        data = data.encode('utf-8')
    return hashlib.sha256(data).hexdigest()

def hmac_sha256(key, data):
    if isinstance(key, str):
        key = key.encode('utf-8')
    if isinstance(data, str):
        data = data.encode('utf-8')
    return hmac.new(key, data, hashlib.sha256).digest()

def get_signature_key(secret_key, date_stamp, region, service):
    k_date = hmac_sha256(secret_key, date_stamp)
    k_region = hmac_sha256(k_date, region)
    k_service = hmac_sha256(k_region, service)
    k_signing = hmac_sha256(k_service, 'request')
    return k_signing

def create_authorization_header(method, path, query_params, headers, payload, access_key, secret_key):
    now = datetime.utcnow()
    amz_date = now.strftime('%Y%m%dT%H%M%SZ')
    date_stamp = now.strftime('%Y%m%d')
    
    canonical_uri = path
    canonical_querystring = '&'.join([f"{quote(k, safe='')}={quote(v, safe='')}" for k, v in sorted(query_params.items())])
    
    signed_headers = ['content-type', 'host', 'x-content-sha256', 'x-date']
    canonical_headers = ''
    for header in signed_headers:
        header_name = header
        if header_name == 'host':
            canonical_headers += f'host:visual.volcengineapi.com\n'
        elif header_name == 'content-type':
            canonical_headers += f'content-type:application/json\n'
        elif header_name == 'x-content-sha256':
            canonical_headers += f'x-content-sha256:{sha256_hash(payload)}\n'
        elif header_name == 'x-date':
            canonical_headers += f'x-date:{amz_date}\n'
    
    signed_headers_str = ';'.join(signed_headers)
    payload_hash = sha256_hash(payload)
    
    canonical_request = f"{method}\n{canonical_uri}\n{canonical_querystring}\n{canonical_headers}\n{signed_headers_str}\n{payload_hash}"
    
    algorithm = 'HMAC-SHA256'
    credential_scope = f"{date_stamp}/{REGION}/{SERVICE}/request"
    string_to_sign = f"{algorithm}\n{amz_date}\n{credential_scope}\n{sha256_hash(canonical_request)}"
    
    signing_key = get_signature_key(secret_key, date_stamp, REGION, SERVICE)
    signature = hmac.new(signing_key, string_to_sign.encode('utf-8'), hashlib.sha256).hexdigest()
    
    authorization_header = f"{algorithm} Credential={access_key}/{credential_scope}, SignedHeaders={signed_headers_str}, Signature={signature}"
    
    return authorization_header, amz_date

def make_api_request(action, body_data):
    query_params = {
        'Action': action,
        'Version': VERSION
    }
    
    payload = json.dumps(body_data)
    
    authorization, amz_date = create_authorization_header(
        'POST', '/', query_params, {}, payload, ACCESS_KEY_ID, SECRET_ACCESS_KEY
    )
    
    headers = {
        'Content-Type': 'application/json',
        'Host': 'visual.volcengineapi.com',
        'X-Date': amz_date,
        'X-Content-Sha256': sha256_hash(payload),
        'Authorization': authorization
    }
    
    url = f"{API_URL}?Action={action}&Version={VERSION}"
    
    response = requests.post(url, headers=headers, data=payload, timeout=60)
    return response.json()

def submit_task(prompt, width=None, height=None, scale=0.5, force_single=True):
    body = {
        "req_key": "jimeng_t2i_v40",
        "prompt": prompt,
        "scale": scale,
        "force_single": force_single
    }
    
    if width and height:
        body["width"] = width
        body["height"] = height
    
    return make_api_request('CVSync2AsyncSubmitTask', body)

def get_task_result(task_id, return_url=True):
    req_json = json.dumps({"return_url": return_url})
    body = {
        "req_key": "jimeng_t2i_v40",
        "task_id": task_id,
        "req_json": req_json
    }
    return make_api_request('CVSync2AsyncGetResult', body)

@app.route('/api/register', methods=['POST'])
def register():
    try:
        data = request.json
        username = data.get('username', '').strip()
        email = data.get('email', '').strip()
        password = data.get('password', '')
        nickname = data.get('nickname', username)
        avatar_base64 = data.get('avatar', '')
        
        if not username or not email or not password:
            return jsonify({'success': False, 'message': '请填写完整信息'}), 400
        
        if len(username) < 3 or len(username) > 20:
            return jsonify({'success': False, 'message': '用户名长度应为3-20个字符'}), 400
        
        if len(password) < 6:
            return jsonify({'success': False, 'message': '密码长度至少6个字符'}), 400
        
        cur = mysql.connection.cursor()
        
        cur.execute('SELECT id FROM users WHERE username = %s', (username,))
        if cur.fetchone():
            cur.close()
            return jsonify({'success': False, 'message': '用户名已存在'}), 400
        
        cur.execute('SELECT id FROM users WHERE email = %s', (email,))
        if cur.fetchone():
            cur.close()
            return jsonify({'success': False, 'message': '邮箱已被注册'}), 400
        
        hashed_password = generate_password_hash(password)
        
        avatar_path = None
        if avatar_base64 and avatar_base64.startswith('data:image'):
            import base64
            import os
            
            avatar_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'public', 'uploads', 'avatars')
            os.makedirs(avatar_dir, exist_ok=True)
            
            try:
                header, b64data = avatar_base64.split(',', 1)
                image_data = base64.b64decode(b64data)
                
                ext = 'png'
                if 'jpeg' in header or 'jpg' in header:
                    ext = 'jpg'
                
                filename = f'{username}_{int(time.time())}.{ext}'
                filepath = os.path.join(avatar_dir, filename)
                
                with open(filepath, 'wb') as f:
                    f.write(image_data)
                
                avatar_path = f'uploads/avatars/{filename}'
            except Exception as img_err:
                print(f"头像保存错误: {img_err}")
        
        if avatar_path:
            cur.execute(
                'INSERT INTO users (username, email, password, nickname, avatar) VALUES (%s, %s, %s, %s, %s)',
                (username, email, hashed_password, nickname, avatar_path)
            )
        else:
            cur.execute(
                'INSERT INTO users (username, email, password, nickname) VALUES (%s, %s, %s, %s)',
                (username, email, hashed_password, nickname)
            )
        mysql.connection.commit()
        
        user_id = cur.lastrowid
        cur.close()
        
        user_id = user_id
        session['username'] = username
        
        return_json = {
            'success': True,
            'message': '注册成功',
            'user': {
                'id': user_id,
                'username': username,
                'email': email,
                'nickname': nickname
            }
        }
        
        if avatar_path:
            return_json['user']['avatar'] = avatar_path
        
        return jsonify(return_json)
        
    except Exception as e:
        print(f"注册错误: {str(e)}")
        import traceback
        traceback.print_exc()
        return jsonify({'success': False, 'message': f'注册失败: {str(e)}'}), 500

@app.route('/api/login', methods=['POST'])
def login():
    try:
        data = request.json
        username = data.get('username', '').strip()
        password = data.get('password', '')
        
        if not username or not password:
            return jsonify({'success': False, 'message': '请填写用户名和密码'}), 400
        
        cur = mysql.connection.cursor()
        cur.execute('SELECT id, username, email, password, nickname, avatar, is_admin FROM users WHERE username = %s OR email = %s', (username, username))
        user = cur.fetchone()
        cur.close()
        
        if not user:
            return jsonify({'success': False, 'message': '用户不存在'}), 400
        
        if not check_password_hash(user['password'], password):
            return jsonify({'success': False, 'message': '密码错误'}), 400
        
        cur = mysql.connection.cursor()
        cur.execute('UPDATE users SET last_login = NOW() WHERE id = %s', (user['id'],))
        mysql.connection.commit()
        cur.close()
        
        user_id = user['id']
        session['username'] = user['username']
        
        token = secrets.token_hex(32)
        user_tokens[token] = user['id']
        
        return jsonify({
            'success': True,
            'message': '登录成功',
            'token': token,
            'user': {
                'id': user['id'],
                'username': user['username'],
                'email': user['email'],
                'nickname': user['nickname'] or user['username'],
                'avatar': user['avatar'],
                'is_admin': user.get('is_admin', 0) == 1
            }
        })
        
    except Exception as e:
        print(f"登录错误: {str(e)}")
        return jsonify({'success': False, 'message': '登录失败，请稍后重试'}), 500

@app.route('/api/logout', methods=['POST'])
def logout():
    token = request.headers.get('Authorization', '').replace('Bearer ', '')
    if token and token in user_tokens:
        del user_tokens[token]
    session.clear()
    return jsonify({'success': True, 'message': '已退出登录'})

@app.route('/api/admin/login', methods=['POST'])
def admin_login():
    try:
        data = request.json
        username = data.get('username', '').strip()
        password = data.get('password', '')
        
        if not username or not password:
            return jsonify({'success': False, 'message': '请填写账号和密码'}), 400
        
        cur = mysql.connection.cursor()
        cur.execute('SELECT id, username, email, password, nickname, avatar, is_admin FROM users WHERE username = %s', (username,))
        user = cur.fetchone()
        cur.close()
        
        if not user:
            return jsonify({'success': False, 'message': '管理员不存在'}), 400
        
        if not check_password_hash(user['password'], password):
            return jsonify({'success': False, 'message': '密码错误'}), 400
        
        if not user.get('is_admin', 0) == 1:
            return jsonify({'success': False, 'message': '不是管理员账号'}), 403
        
        cur = mysql.connection.cursor()
        cur.execute('UPDATE users SET last_login = NOW() WHERE id = %s', (user['id'],))
        mysql.connection.commit()
        cur.close()
        
        user_id = user['id']
        session['username'] = user['username']
        
        token = secrets.token_hex(32)
        user_tokens[token] = user['id']
        
        return jsonify({
            'success': True,
            'message': '登录成功',
            'token': token,
            'user': {
                'id': user['id'],
                'username': user['username'],
                'email': user['email'],
                'nickname': user['nickname'] or user['username'],
                'avatar': user['avatar'],
                'is_admin': True
            }
        })
        
    except Exception as e:
        print(f"管理员登录错误: {str(e)}")
        return jsonify({'success': False, 'message': '登录失败，请稍后重试'}), 500

@app.route('/api/user/info', methods=['GET'])
def get_user_info():
    user_id = get_current_user_id()
    if not user_id:
        return jsonify({'success': False, 'message': '未登录'}), 401
    
    try:
        cur = mysql.connection.cursor()
        cur.execute('SELECT id, username, email, nickname, avatar, created_at, is_admin FROM users WHERE id = %s', (user_id,))
        user = cur.fetchone()
        cur.close()
        
        if not user:
            session.clear()
            return jsonify({'success': False, 'message': '用户不存在'}), 401
        
        return jsonify({
            'success': True,
            'user': {
                'id': user['id'],
                'username': user['username'],
                'email': user['email'],
                'nickname': user['nickname'] or user['username'],
                'avatar': user['avatar'],
                'is_admin': user.get('is_admin', 0) == 1,
                'created_at': user['created_at'].strftime('%Y-%m-%d') if user['created_at'] else None
            }
        })
        
    except Exception as e:
        print(f"获取用户信息错误: {str(e)}")
        return jsonify({'success': False, 'message': '获取用户信息失败'}), 500

@app.route('/api/user/update', methods=['POST'])
def update_user_info():
    user_id = get_current_user_id()
    if not user_id:
        return jsonify({'success': False, 'message': '未登录'}), 401
    
    try:
        data = request.json
        nickname = data.get('nickname', '').strip()
        
        if nickname:
            cur = mysql.connection.cursor()
            cur.execute('UPDATE users SET nickname = %s WHERE id = %s', (nickname, user_id))
            mysql.connection.commit()
            cur.close()
        
        return jsonify({'success': True, 'message': '更新成功'})
        
    except Exception as e:
        print(f"更新用户信息错误: {str(e)}")
        return jsonify({'success': False, 'message': '更新失败'}), 500

@app.route('/api/chat', methods=['POST'])
def chat():
    try:
        from volcenginesdkarkruntime import Ark
        
        data = request.json
        user_message = data.get('message', '')
        
        if not user_message:
            return jsonify({'error': '消息不能为空'}), 400
        
        client = Ark(
            base_url='https://ark.cn-beijing.volces.com/api/v3',
            api_key=ARK_API_KEY,
        )
        
        response = client.chat.completions.create(
            model=ARK_MODEL_ID,
            messages=[
                {
                    "role": "system",
                    "content": "你是雷州石狗文化的AI助手，专门回答关于雷州石狗历史、文化、艺术等方面的问题。请用专业、友好的语气回答用户的问题。"
                },
                {
                    "role": "user",
                    "content": user_message
                }
            ],
            stream=False,
            max_tokens=4096,
            temperature=0.7
        )
        
        ai_response = response.choices[0].message.content
        
        return jsonify({
            'success': True,
            'response': ai_response
        })
            
    except Exception as e:
        print(f"聊天错误: {str(e)}")
        import traceback
        traceback.print_exc()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/optimize-prompt', methods=['POST'])
def optimize_prompt():
    print("收到提示词优化请求")
    try:
        from volcenginesdkarkruntime import Ark
        print("Ark模块导入成功")
        
        data = request.json
        user_prompt = data.get('prompt', '')
        print(f"用户提示词: {user_prompt}")
        
        if not user_prompt:
            return jsonify({'success': False, 'message': '提示词不能为空'}), 400
        
        print(f"使用API Key: {ARK_API_KEY[:10]}...")
        print(f"使用Model ID: {ARK_MODEL_ID}")
        
        client = Ark(
            base_url='https://ark.cn-beijing.volces.com/api/v3',
            api_key=ARK_API_KEY,
        )
        print("Ark客户端创建成功")
        
        response = client.chat.completions.create(
            model=ARK_MODEL_ID,
            messages=[
                {
                    "role": "system",
                    "content": """你是一个专业的AI绘画提示词优化专家。用户会给你一个简单的描述，你需要将其优化为更详细、更专业的AI绘画提示词。

优化要求：
1. 保持用户原始意图不变
2. 添加更多细节描述（如光影、构图、风格、氛围等）
3. 使用专业的艺术术语
4. 提示词要适合AI图像生成
5. 如果是石狗相关内容，要融入雷州石狗文化元素
6. 直接输出优化后的提示词，不要解释

示例：
用户输入：一个石狗
优化输出：一尊古老的雷州石狗雕像，青石材质，雕刻精细，威严庄重，传统岭南风格，阳光照射下形成明暗对比，背景是古老的雷州村落，青砖黛瓦，充满历史沧桑感，4K高清，写实风格"""
                },
                {
                    "role": "user",
                    "content": f"请优化这个AI绘画提示词：{user_prompt}"
                }
            ],
            stream=False,
            max_tokens=1024,
            temperature=0.7
        )
        print("API调用成功")
        
        optimized_prompt = response.choices[0].message.content
        print(f"优化后的提示词: {optimized_prompt[:50]}...")
        
        return jsonify({
            'success': True,
            'original_prompt': user_prompt,
            'optimized_prompt': optimized_prompt
        })
            
    except Exception as e:
        print(f"提示词优化错误: {str(e)}")
        import traceback
        traceback.print_exc()
        return jsonify({
            'success': False,
            'message': f'优化失败: {str(e)}'
        }), 500

@app.route('/api/image-gen', methods=['POST'])
def image_gen():
    try:
        data = request.json
        prompt = data.get('prompt', '')
        width = data.get('width', 2048)
        height = data.get('height', 2048)
        scale = data.get('scale', 0.5)
        force_single = data.get('force_single', True)
        
        print(f"收到图像生成请求: prompt={prompt}, width={width}, height={height}, scale={scale}")
        
        if not prompt:
            return jsonify({'success': False, 'message': '请输入画面描述'}), 400
        
        print("提交任务到火山引擎...")
        submit_result = submit_task(prompt, width, height, scale, force_single)
        print(f"提交结果: {submit_result}")
        
        if submit_result.get('code') != 10000:
            error_msg = submit_result.get('message', '提交任务失败')
            return jsonify({'success': False, 'message': error_msg}), 500
        
        task_id = submit_result.get('data', {}).get('task_id')
        if not task_id:
            return jsonify({'success': False, 'message': '未获取到任务ID'}), 500
        
        print(f"任务ID: {task_id}, 开始轮询结果...")
        
        max_attempts = 60
        for attempt in range(max_attempts):
            time.sleep(2)
            
            result = get_task_result(task_id)
            print(f"轮询第{attempt + 1}次: {result}")
            
            status = result.get('data', {}).get('status', '')
            
            if status == 'done':
                image_urls = result.get('data', {}).get('image_urls', [])
                if image_urls:
                    uid = get_current_user_id()
                    print(f"AI生成完成，获取用户ID: {uid}")
                    if uid:
                        try:
                            cur = mysql.connection.cursor()
                            cur.execute('''
                                INSERT INTO ai_generation_history (user_id, prompt, image_url, width, height)
                                VALUES (%s, %s, %s, %s, %s)
                            ''', (uid, prompt, image_urls[0], width, height))
                            mysql.connection.commit()
                            cur.close()
                            print(f"AI历史保存成功, user_id: {uid}, prompt: {prompt[:30]}...")
                        except Exception as e:
                            print(f"保存AI历史错误: {str(e)}")
                    else:
                        print("未获取到用户ID，跳过保存AI历史")
                    
                    return jsonify({
                        'success': True,
                        'image_url': image_urls[0],
                        'all_images': image_urls
                    })
                else:
                    return jsonify({'success': False, 'message': '未生成图片'}), 500
            
            elif status == 'not_found':
                return jsonify({'success': False, 'message': '任务未找到或已过期'}), 500
            
            elif status == 'expired':
                return jsonify({'success': False, 'message': '任务已过期，请重试'}), 500
            
            elif status in ['in_queue', 'generating']:
                continue
            
            else:
                if result.get('code') != 10000:
                    return jsonify({'success': False, 'message': result.get('message', '生成失败')}), 500
        
        return jsonify({'success': False, 'message': '生成超时，请稍后重试'}), 500
            
    except Exception as e:
        print(f"图像生成错误: {str(e)}")
        import traceback
        traceback.print_exc()
        return jsonify({
            'success': False,
            'message': str(e)
        }), 500

@app.route('/api/report', methods=['POST'])
def submit_report():
    user_id = get_current_user_id()
    if not user_id:
        return jsonify({'success': False, 'message': '请先登录'}), 401
    
    try:
        data = request.json
        
        title = data.get('title', '').strip()
        shigou_type = data.get('shigou_type', '').strip()
        location = data.get('location', '').strip()
        latitude = data.get('latitude')
        longitude = data.get('longitude')
        discovery_date = data.get('discovery_date')
        height = data.get('height')
        width = data.get('width')
        depth = data.get('depth')
        material = data.get('material', '').strip() or None
        description = data.get('description', '').strip()
        images = data.get('images', [])
        contact = data.get('contact', '').strip() or None
        
        if not title:
            return jsonify({'success': False, 'message': '请输入石狗名称'}), 400
        if not shigou_type:
            return jsonify({'success': False, 'message': '请选择石狗类型'}), 400
        if not location:
            return jsonify({'success': False, 'message': '请输入发现地点'}), 400
        
        saved_images = []
        if images and len(images) > 0:
            import base64
            import os
            
            upload_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'public', 'uploads', 'reports')
            os.makedirs(upload_dir, exist_ok=True)
            
            for i, img_data in enumerate(images[:5]):
                try:
                    if img_data.startswith('data:image'):
                        header, b64data = img_data.split(',', 1)
                        image_bytes = base64.b64decode(b64data)
                        
                        ext = 'png'
                        if 'jpeg' in header or 'jpg' in header:
                            ext = 'jpg'
                        
                        filename = f'report_{session["user_id"]}_{int(time.time())}_{i}.{ext}'
                        filepath = os.path.join(upload_dir, filename)
                        
                        with open(filepath, 'wb') as f:
                            f.write(image_bytes)
                        
                        saved_images.append(f'uploads/reports/{filename}')
                except Exception as img_err:
                    print(f"图片保存错误: {img_err}")
        
        images_json = json.dumps(saved_images) if saved_images else None
        
        cur = mysql.connection.cursor()
        cur.execute('''
            INSERT INTO shigou_reports 
            (user_id, title, shigou_type, location, latitude, longitude, discovery_date, 
             height, width, depth, material, description, images, contact)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        ''', (
            user_id, title, shigou_type, location, latitude, longitude, discovery_date,
            height, width, depth, material, description, images_json, contact
        ))
        mysql.connection.commit()
        report_id = cur.lastrowid
        cur.close()
        
        return jsonify({
            'success': True,
            'message': '上报成功',
            'report_id': report_id
        })
        
    except Exception as e:
        print(f"上报错误: {str(e)}")
        import traceback
        traceback.print_exc()
        return jsonify({'success': False, 'message': '上报失败，请稍后重试'}), 500

@app.route('/api/my-reports', methods=['GET'])
def get_my_reports():
    user_id = get_current_user_id()
    if not user_id:
        return jsonify({'success': False, 'message': '请先登录'}), 401
    
    try:
        cur = mysql.connection.cursor()
        cur.execute('''
            SELECT id, title, shigou_type, location, status, created_at, admin_note
            FROM shigou_reports 
            WHERE user_id = %s 
            ORDER BY created_at DESC
        ''', (user_id,))
        reports = cur.fetchall()
        cur.close()
        
        result = []
        for r in reports:
            result.append({
                'id': r['id'],
                'title': r['title'],
                'shigou_type': r['shigou_type'],
                'location': r['location'],
                'status': r['status'],
                'status_text': {0: '待审核', 1: '已通过', 2: '已拒绝'}.get(r['status'], '未知'),
                'created_at': r['created_at'].strftime('%Y-%m-%d %H:%M') if r['created_at'] else None,
                'admin_note': r['admin_note']
            })
        
        return jsonify({'success': True, 'reports': result})
        
    except Exception as e:
        print(f"获取上报列表错误: {str(e)}")
        return jsonify({'success': False, 'message': '获取失败'}), 500

# ============ 论坛API ============

@app.route('/api/posts', methods=['GET'])
def get_posts():
    try:
        post_type = request.args.get('type', None)
        
        cur = mysql.connection.cursor()
        
        if post_type and post_type != 'all':
            cur.execute('''
                SELECT p.*, u.nickname, u.username as author_name,
                       (SELECT COUNT(*) FROM post_likes WHERE post_id = p.id) as like_count,
                       (SELECT COUNT(*) FROM post_comments WHERE post_id = p.id) as comment_count
                FROM forum_posts p
                JOIN users u ON p.user_id = u.id
                WHERE p.image_type = %s
                ORDER BY p.is_pinned DESC, p.created_at DESC
                LIMIT 50
            ''', (post_type,))
        else:
            cur.execute('''
                SELECT p.*, u.nickname, u.username as author_name,
                       (SELECT COUNT(*) FROM post_likes WHERE post_id = p.id) as like_count,
                       (SELECT COUNT(*) FROM post_comments WHERE post_id = p.id) as comment_count
                FROM forum_posts p
                JOIN users u ON p.user_id = u.id
                ORDER BY p.is_pinned DESC, p.created_at DESC
                LIMIT 50
            ''')
        
        posts = cur.fetchall()
        cur.close()
        
        result = []
        for p in posts:
            result.append({
                'id': p['id'],
                'user_id': p['user_id'],
                'title': p['title'],
                'content': p['content'],
                'image_url': p['image_url'],
                'image_type': p['image_type'],
                'prompt': p['prompt'],
                'author_name': p['nickname'] or p['author_name'],
                'like_count': p['like_count'],
                'comment_count': p['comment_count'],
                'view_count': p['view_count'],
                'created_at': p['created_at'].strftime('%Y-%m-%d %H:%M') if p['created_at'] else None
            })
        
        return jsonify({'success': True, 'posts': result})
        
    except Exception as e:
        print(f"获取帖子列表错误: {str(e)}")
        return jsonify({'success': False, 'message': '获取失败'}), 500

@app.route('/api/posts', methods=['POST'])
def create_post():
    user_id = get_current_user_id()
    if not user_id:
        return jsonify({'success': False, 'message': '请先登录'}), 401
    
    try:
        data = request.json
        title = data.get('title', '').strip()
        content = data.get('content', '').strip()
        image_type = data.get('image_type', 'uploaded')
        prompt = data.get('prompt', '').strip()
        image_base64 = data.get('image_base64', '')
        
        print(f"创建帖子 - title: {title}, image_base64长度: {len(image_base64)}, image_base64前20字符: {image_base64[:20] if image_base64 else 'None'}")
        
        if not title:
            return jsonify({'success': False, 'message': '请输入标题'}), 400
        
        image_url = None
        if image_base64:
            if image_base64.startswith('data:image'):
                import base64
                import os
                
                upload_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'public', 'uploads', 'forum')
                os.makedirs(upload_dir, exist_ok=True)
                
                try:
                    header, b64data = image_base64.split(',', 1)
                    image_bytes = base64.b64decode(b64data)
                    
                    ext = 'png'
                    if 'jpeg' in header or 'jpg' in header:
                        ext = 'jpg'
                    
                    filename = f'post_{user_id}_{int(time.time())}.{ext}'
                    filepath = os.path.join(upload_dir, filename)
                    
                    with open(filepath, 'wb') as f:
                        f.write(image_bytes)
                    
                    image_url = f'uploads/forum/{filename}'
                    print(f"图片保存成功: {image_url}")
                except Exception as img_err:
                    print(f"图片保存错误: {img_err}")
            elif image_base64.startswith('http'):
                image_url = image_base64
                print(f"使用图片URL: {image_url}")
        else:
            print("image_base64为空")
        
        print(f"最终image_url: {image_url}")
        
        cur = mysql.connection.cursor()
        cur.execute('''
            INSERT INTO forum_posts (user_id, title, content, image_url, image_type, prompt)
            VALUES (%s, %s, %s, %s, %s, %s)
        ''', (user_id, title, content, image_url, image_type, prompt or None))
        mysql.connection.commit()
        post_id = cur.lastrowid
        cur.close()
        
        return jsonify({'success': True, 'post_id': post_id})
        
    except Exception as e:
        print(f"创建帖子错误: {str(e)}")
        return jsonify({'success': False, 'message': '发布失败'}), 500

@app.route('/api/posts/<int:post_id>', methods=['GET'])
def get_post(post_id):
    try:
        cur = mysql.connection.cursor()
        
        cur.execute('''
            UPDATE forum_posts SET view_count = view_count + 1 WHERE id = %s
        ''', (post_id,))
        mysql.connection.commit()
        
        cur.execute('''
            SELECT p.*, u.nickname, u.username as author_name,
                   (SELECT COUNT(*) FROM post_likes WHERE post_id = p.id) as like_count,
                   (SELECT COUNT(*) FROM post_comments WHERE post_id = p.id) as comment_count
            FROM forum_posts p
            JOIN users u ON p.user_id = u.id
            WHERE p.id = %s
        ''', (post_id,))
        post = cur.fetchone()
        cur.close()
        
        if not post:
            return jsonify({'success': False, 'message': '帖子不存在'}), 404
        
        is_liked = False
        if 'user_id' in session:
            cur = mysql.connection.cursor()
            cur.execute('SELECT id FROM post_likes WHERE post_id = %s AND user_id = %s', (post_id, user_id))
            is_liked = cur.fetchone() is not None
            cur.close()
        
        return jsonify({
            'success': True,
            'post': {
                'id': post['id'],
                'title': post['title'],
                'content': post['content'],
                'image_url': post['image_url'],
                'image_type': post['image_type'],
                'prompt': post['prompt'],
                'author_name': post['nickname'] or post['author_name'],
                'like_count': post['like_count'],
                'comment_count': post['comment_count'],
                'view_count': post['view_count'],
                'is_liked': is_liked,
                'created_at': post['created_at'].strftime('%Y-%m-%d %H:%M') if post['created_at'] else None
            }
        })
        
    except Exception as e:
        print(f"获取帖子详情错误: {str(e)}")
        return jsonify({'success': False, 'message': '获取失败'}), 500

@app.route('/api/posts/<int:post_id>', methods=['DELETE'])
def delete_post(post_id):
    user_id = get_current_user_id()
    if not user_id:
        return jsonify({'success': False, 'message': '请先登录'}), 401
    
    try:
        cur = mysql.connection.cursor()
        
        # 检查用户是否为管理员
        cur.execute('SELECT is_admin FROM users WHERE id = %s', (user_id,))
        user = cur.fetchone()
        is_admin = user.get('is_admin', 0) == 1
        
        # 获取帖子信息
        cur.execute('SELECT user_id FROM forum_posts WHERE id = %s', (post_id,))
        post = cur.fetchone()
        
        if not post:
            cur.close()
            return jsonify({'success': False, 'message': '帖子不存在'}), 404
        
        # 只有帖子作者或管理员可以删除
        if post['user_id'] != user_id and not is_admin:
            cur.close()
            return jsonify({'success': False, 'message': '无权删除此帖子'}), 403
        
        cur.execute('DELETE FROM post_likes WHERE post_id = %s', (post_id,))
        cur.execute('DELETE FROM post_comments WHERE post_id = %s', (post_id,))
        cur.execute('DELETE FROM forum_posts WHERE id = %s', (post_id,))
        mysql.connection.commit()
        cur.close()
        
        return jsonify({'success': True, 'message': '删除成功'})
        
    except Exception as e:
        print(f"删除帖子错误: {str(e)}")
        return jsonify({'success': False, 'message': '删除失败'}), 500

@app.route('/api/posts/<int:post_id>/like', methods=['POST'])
def toggle_like(post_id):
    user_id = get_current_user_id()
    if not user_id:
        return jsonify({'success': False, 'message': '请先登录'}), 401
    
    try:
        cur = mysql.connection.cursor()
        
        cur.execute('SELECT id FROM post_likes WHERE post_id = %s AND user_id = %s', (post_id, user_id))
        existing = cur.fetchone()
        
        if existing:
            cur.execute('DELETE FROM post_likes WHERE post_id = %s AND user_id = %s', (post_id, user_id))
            liked = False
        else:
            cur.execute('INSERT INTO post_likes (post_id, user_id) VALUES (%s, %s)', (post_id, user_id))
            liked = True
        
        mysql.connection.commit()
        
        cur.execute('SELECT COUNT(*) as count FROM post_likes WHERE post_id = %s', (post_id,))
        like_count = cur.fetchone()['count']
        cur.close()
        
        return jsonify({'success': True, 'liked': liked, 'like_count': like_count})
        
    except Exception as e:
        print(f"点赞错误: {str(e)}")
        return jsonify({'success': False, 'message': '操作失败'}), 500

@app.route('/api/posts/<int:post_id>/comments', methods=['GET'])
def get_comments(post_id):
    try:
        cur = mysql.connection.cursor()
        cur.execute('''
            SELECT c.*, u.nickname, u.username as author_name
            FROM post_comments c
            JOIN users u ON c.user_id = u.id
            WHERE c.post_id = %s
            ORDER BY c.created_at DESC
        ''', (post_id,))
        comments = cur.fetchall()
        cur.close()
        
        result = []
        for c in comments:
            result.append({
                'id': c['id'],
                'content': c['content'],
                'author_name': c['nickname'] or c['author_name'],
                'created_at': c['created_at'].strftime('%Y-%m-%d %H:%M') if c['created_at'] else None
            })
        
        return jsonify({'success': True, 'comments': result})
        
    except Exception as e:
        print(f"获取评论错误: {str(e)}")
        return jsonify({'success': False, 'message': '获取失败'}), 500

@app.route('/api/posts/<int:post_id>/comments', methods=['POST'])
def add_comment(post_id):
    user_id = get_current_user_id()
    if not user_id:
        return jsonify({'success': False, 'message': '请先登录'}), 401
    
    try:
        data = request.json
        content = data.get('content', '').strip()
        
        if not content:
            return jsonify({'success': False, 'message': '评论内容不能为空'}), 400
        
        cur = mysql.connection.cursor()
        cur.execute('''
            INSERT INTO post_comments (post_id, user_id, content)
            VALUES (%s, %s, %s)
        ''', (post_id, user_id, content))
        mysql.connection.commit()
        
        cur.execute('SELECT COUNT(*) as count FROM post_comments WHERE post_id = %s', (post_id,))
        comment_count = cur.fetchone()['count']
        cur.close()
        
        return jsonify({'success': True, 'comment_count': comment_count})
        
    except Exception as e:
        print(f"添加评论错误: {str(e)}")
        return jsonify({'success': False, 'message': '评论失败'}), 500

# ============ 用户中心API ============

@app.route('/api/user/stats', methods=['GET'])
def get_user_stats():
    user_id = get_current_user_id()
    if not user_id:
        return jsonify({'success': False, 'message': '请先登录'}), 401
    
    try:
        cur = mysql.connection.cursor()
        
        cur.execute('SELECT COUNT(*) as count FROM forum_posts WHERE user_id = %s', (user_id,))
        post_count = cur.fetchone()['count']
        
        cur.execute('''
            SELECT COUNT(*) as count FROM post_likes pl
            JOIN forum_posts p ON pl.post_id = p.id
            WHERE p.user_id = %s
        ''', (user_id,))
        like_count = cur.fetchone()['count']
        
        cur.execute('SELECT COUNT(*) as count FROM ai_generation_history WHERE user_id = %s', (user_id,))
        ai_count = cur.fetchone()['count']
        
        cur.close()
        
        return jsonify({
            'success': True,
            'stats': {
                'post_count': post_count,
                'like_count': like_count,
                'ai_count': ai_count
            }
        })
        
    except Exception as e:
        print(f"获取统计错误: {str(e)}")
        return jsonify({'success': False, 'message': '获取失败'}), 500

@app.route('/api/user/ai-history', methods=['GET'])
def get_ai_history():
    user_id = get_current_user_id()
    if not user_id:
        return jsonify({'success': False, 'message': '请先登录'}), 401
    
    try:
        cur = mysql.connection.cursor()
        cur.execute('''
            SELECT id, prompt, image_url, created_at
            FROM ai_generation_history
            WHERE user_id = %s
            ORDER BY created_at DESC
            LIMIT 50
        ''', (user_id,))
        history = cur.fetchall()
        cur.close()
        
        result = []
        for h in history:
            result.append({
                'id': h['id'],
                'prompt': h['prompt'],
                'image_url': h['image_url'],
                'created_at': h['created_at'].strftime('%Y-%m-%d %H:%M') if h['created_at'] else None
            })
        
        return jsonify({'success': True, 'history': result})
        
    except Exception as e:
        print(f"获取AI历史错误: {str(e)}")
        return jsonify({'success': True, 'history': []})

@app.route('/api/user/posts', methods=['GET'])
def get_user_posts():
    user_id = get_current_user_id()
    if not user_id:
        return jsonify({'success': False, 'message': '请先登录'}), 401
    
    try:
        cur = mysql.connection.cursor()
        cur.execute('''
            SELECT id, title, image_url, like_count, comment_count, created_at
            FROM forum_posts
            WHERE user_id = %s
            ORDER BY created_at DESC
        ''', (user_id,))
        posts = cur.fetchall()
        cur.close()
        
        result = []
        for p in posts:
            result.append({
                'id': p['id'],
                'title': p['title'],
                'image_url': p['image_url'],
                'like_count': p['like_count'] or 0,
                'comment_count': p['comment_count'] or 0,
                'created_at': p['created_at'].strftime('%Y-%m-%d %H:%M') if p['created_at'] else None
            })
        
        return jsonify({'success': True, 'posts': result})
        
    except Exception as e:
        print(f"获取用户帖子错误: {str(e)}")
        return jsonify({'success': True, 'posts': []})

@app.route('/api/user/update', methods=['POST'])
def update_user_profile():
    user_id = get_current_user_id()
    if not user_id:
        return jsonify({'success': False, 'message': '请先登录'}), 401
    
    try:
        data = request.json
        nickname = data.get('nickname', '').strip()
        
        if nickname:
            cur = mysql.connection.cursor()
            cur.execute('UPDATE users SET nickname = %s WHERE id = %s', (nickname, user_id))
            mysql.connection.commit()
            cur.close()
        
        return jsonify({'success': True, 'message': '更新成功'})
        
    except Exception as e:
        print(f"更新用户信息错误: {str(e)}")
        return jsonify({'success': False, 'message': '更新失败'}), 500

@app.route('/api/user/password', methods=['POST'])
def change_password():
    user_id = get_current_user_id()
    if not user_id:
        return jsonify({'success': False, 'message': '请先登录'}), 401
    
    try:
        data = request.json
        old_password = data.get('old_password', '')
        new_password = data.get('new_password', '')
        
        if not old_password or not new_password:
            return jsonify({'success': False, 'message': '请填写完整信息'}), 400
        
        if len(new_password) < 6:
            return jsonify({'success': False, 'message': '新密码至少6位'}), 400
        
        cur = mysql.connection.cursor()
        cur.execute('SELECT password FROM users WHERE id = %s', (user_id,))
        user = cur.fetchone()
        
        if not user:
            cur.close()
            return jsonify({'success': False, 'message': '用户不存在'}), 404
        
        if not check_password_hash(user['password'], old_password):
            cur.close()
            return jsonify({'success': False, 'message': '原密码错误'}), 400
        
        new_hash = generate_password_hash(new_password)
        cur.execute('UPDATE users SET password = %s WHERE id = %s', (new_hash, user_id))
        mysql.connection.commit()
        cur.close()
        
        return jsonify({'success': True, 'message': '密码修改成功'})
        
    except Exception as e:
        print(f"修改密码错误: {str(e)}")
        return jsonify({'success': False, 'message': '修改失败'}), 500

@app.route('/api/user/avatar', methods=['POST'])
def upload_avatar():
    user_id = get_current_user_id()
    print(f"上传头像请求 - user_id: {user_id}")
    if not user_id:
        return jsonify({'success': False, 'message': '请先登录'}), 401
    
    try:
        data = request.json
        avatar_base64 = data.get('avatar', '')
        
        print(f"收到头像数据 - 长度: {len(avatar_base64)}, 前50字符: {avatar_base64[:50] if avatar_base64 else 'None'}")
        
        if not avatar_base64 or not avatar_base64.startswith('data:image'):
            return jsonify({'success': False, 'message': '无效图片'}), 400
        
        import base64
        import os
        
        avatar_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'public', 'uploads', 'avatars')
        os.makedirs(avatar_dir, exist_ok=True)
        print(f"头像保存目录: {avatar_dir}")
        
        header, b64data = avatar_base64.split(',', 1)
        image_bytes = base64.b64decode(b64data)
        
        ext = 'png'
        if 'jpeg' in header or 'jpg' in header:
            ext = 'jpg'
        
        filename = f'user_{user_id}_{int(time.time())}.{ext}'
        filepath = os.path.join(avatar_dir, filename)
        
        with open(filepath, 'wb') as f:
            f.write(image_bytes)
        
        print(f"头像文件保存成功: {filepath}")
        
        avatar_url = f'uploads/avatars/{filename}'
        
        cur = mysql.connection.cursor()
        cur.execute('UPDATE users SET avatar = %s WHERE id = %s', (avatar_url, user_id))
        mysql.connection.commit()
        cur.close()
        
        print(f"头像URL已更新到数据库: {avatar_url}")
        
        return jsonify({'success': True, 'avatar_url': avatar_url})
        
    except Exception as e:
        print(f"上传头像错误: {str(e)}")
        return jsonify({'success': False, 'message': '上传失败'}), 500

def init_admin():
    try:
        cur = mysql.connection.cursor()
        
        # 检查users表是否有is_admin字段
        cur.execute("SHOW COLUMNS FROM users LIKE 'is_admin'")
        result = cur.fetchone()
        
        if not result:
            # 添加is_admin字段
            cur.execute("ALTER TABLE users ADD COLUMN is_admin TINYINT(1) DEFAULT 0")
            print("已添加is_admin字段")
        
        # 检查管理员用户是否已存在
        cur.execute("SELECT id FROM users WHERE username = 'admin'")
        admin = cur.fetchone()
        
        if not admin:
            # 创建管理员用户
            from werkzeug.security import generate_password_hash
            hashed_password = generate_password_hash('admin123')
            cur.execute(
                "INSERT INTO users (username, email, password, nickname, is_admin) VALUES (%s, %s, %s, %s, %s)",
                ('admin', 'admin@example.com', hashed_password, '管理员', 1)
            )
            mysql.connection.commit()
            print("管理员用户创建成功")
        else:
            # 更新现有管理员用户的is_admin字段
            cur.execute("UPDATE users SET is_admin = 1 WHERE username = 'admin'")
            mysql.connection.commit()
            print("管理员用户已存在，已更新权限")
        
        cur.close()
        print("管理员初始化完成")
        
    except Exception as e:
        print(f"初始化管理员错误: {str(e)}")

if __name__ == '__main__':
    with app.app_context():
        init_admin()
    app.run(port=5001, debug=False)
