from flask import Flask, request, jsonify
from flask_cors import CORS
from zai import ZhipuAiClient
from volcengine.visual.VisualService import VisualService

app = Flask(__name__)
CORS(app)

client = ZhipuAiClient(api_key="037a2581df269fce0d3c3a7b538b8d76.HXVGeRwJkHGuvA9g")

image_service = VisualService()

image_service.set_ak("AKLTMmJmY2UxOGMzZWNhNDE4ZThjOTM1YTdlNTYyMGVhNGQ")
image_service.set_sk("ZjFkMWU4NjM0MTY1NDU3YmFkOGYxYTY3ZjgxZTQ5NDE")

@app.route('/api/chat', methods=['POST'])
def chat():
    try:
        data = request.json
        user_message = data.get('message', '')
        
        if not user_message:
            return jsonify({'error': '消息不能为空'}), 400
        
        response = client.chat.completions.create(
            model="glm-4.5-flash",
            messages=[
                {
                    "role": "system",
                    "content": "你是雷州石狗文化的AI助手，专门回答关于雷州石狗历史、文化、艺术等方面的问题。请用专业、友好的语气回答用户的问题。"
                },
                {
                    "role": "user",
                    "content": user_message
                }
            ],
            thinking={
                "type": "enabled"
            },
            stream=False,
            max_tokens=4096,
            temperature=0.7
        )
        
        ai_response = response.choices[0].message.content
        
        return jsonify({
            'success': True,
            'response': ai_response
        })
            
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/image-gen', methods=['POST'])
def image_gen():
    try:
        data = request.json
        prompt = data.get('prompt', '')
        width = data.get('width', 1328)
        height = data.get('height', 1328)
        scale = data.get('scale', 2.5)
        seed = data.get('seed', -1)
        use_pre_llm = data.get('use_pre_llm', False)
        
        print(f"收到图像生成请求: prompt={prompt}, width={width}, height={height}, scale={scale}, seed={seed}, use_pre_llm={use_pre_llm}")
        
        if not prompt:
            return jsonify({'success': False, 'message': '请输入画面描述'}), 400
        
        resp = image_service.cv_process(
            req_key="high_aes_general_v30l_zt2i",
            prompt=prompt,
            width=width,
            height=height,
            scale=scale,
            seed=seed,
            use_pre_llm=use_pre_llm,
            return_url=True,
            logo_info={
                "add_logo": False
            }
        )
        
        print(f"火山引擎API返回: {resp}")
        
        if resp.get('ResponseMetadata', {}).get('Error'):
            error = resp['ResponseMetadata']['Error']
            return jsonify({
                'success': False,
                'message': error.get('Message', '生成图像失败')
            }), 500
        
        image_urls = resp.get('Result', {}).get('image_urls', [])
        if image_urls:
            return jsonify({
                'success': True,
                'image_url': image_urls[0]
            })
        else:
            return jsonify({'success': False, 'message': '未返回图像URL'}), 500
            
    except Exception as e:
        print(f"图像生成错误: {str(e)}")
        import traceback
        traceback.print_exc()
        return jsonify({
            'success': False,
            'message': str(e)
        }), 500

if __name__ == '__main__':
    app.run(port=5001, debug=False)
