import os
from volcenginesdkarkruntime import Ark

ARK_API_KEY = "cce8b0d2-6b92-41ca-8d1f-0ea5fffd36b0"
ARK_MODEL_ID = "ep-m-20260313104555-brgnz"

def chat_with_doubao(message, system_prompt=None):
    """
    调用豆包AI进行对话
    
    参数:
        message: 用户消息
        system_prompt: 系统提示词（可选）
    
    返回:
        AI的回复文本
    """
    client = Ark(
        base_url='https://ark.cn-beijing.volces.com/api/v3',
        api_key=ARK_API_KEY,
    )
    
    messages = []
    
    if system_prompt:
        messages.append({
            "role": "system",
            "content": system_prompt
        })
    
    messages.append({
        "role": "user",
        "content": message
    })
    
    response = client.chat.completions.create(
        model=ARK_MODEL_ID,
        messages=messages,
        stream=False,
        max_tokens=4096,
        temperature=0.7
    )
    
    return response.choices[0].message.content


def chat_with_doubao_stream(message, system_prompt=None):
    """
    调用豆包AI进行流式对话
    
    参数:
        message: 用户消息
        system_prompt: 系统提示词（可选）
    
    返回:
        生成器，逐步返回AI的回复
    """
    client = Ark(
        base_url='https://ark.cn-beijing.volces.com/api/v3',
        api_key=ARK_API_KEY,
    )
    
    messages = []
    
    if system_prompt:
        messages.append({
            "role": "system",
            "content": system_prompt
        })
    
    messages.append({
        "role": "user",
        "content": message
    })
    
    stream = client.chat.completions.create(
        model=ARK_MODEL_ID,
        messages=messages,
        stream=True,
        max_tokens=4096,
        temperature=0.7
    )
    
    for chunk in stream:
        if chunk.choices and chunk.choices[0].delta.content:
            yield chunk.choices[0].delta.content


if __name__ == "__main__":
    print("=" * 50)
    print("豆包AI 调用示例")
    print("=" * 50)
    
    print("\n【普通模式】")
    result = chat_with_doubao(
        message="你好，请介绍一下雷州石狗文化",
        system_prompt="你是雷州石狗文化的AI助手，专门回答关于雷州石狗历史、文化、艺术等方面的问题。"
    )
    print(result)
    
    print("\n" + "=" * 50)
    print("【流式模式】")
    for text in chat_with_doubao_stream(
        message="请用一句话介绍雷州石狗",
        system_prompt="你是雷州石狗文化的AI助手。"
    ):
        print(text, end="", flush=True)
    print("\n")
