import pymysql
from werkzeug.security import generate_password_hash

conn = pymysql.connect(
    host='localhost',
    user='root',
    password='Hjshzhz110',
    database='shigou_db',
    charset='utf8mb4'
)

try:
    cur = conn.cursor()
    
    username = 'testuser999'
    email = 'test999@test.com'
    password = '123456'
    nickname = username
    hashed_password = generate_password_hash(password)
    
    cur.execute(
        'INSERT INTO users (username, email, password, nickname) VALUES (%s, %s, %s, %s)',
        (username, email, hashed_password, nickname)
    )
    conn.commit()
    print("注册成功！")
    print(f"用户ID: {cur.lastrowid}")
    
except Exception as e:
    print(f"错误: {e}")
finally:
    conn.close()
