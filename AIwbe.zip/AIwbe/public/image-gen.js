let selectedWidth = 2048;
let selectedHeight = 2048;
let currentImageUrl = '';
let allGeneratedImages = [];

const sizeOptions = [
    { width: 1024, height: 1024, name: '1K 1:1', detail: '1024×1024' },
    { width: 2048, height: 2048, name: '2K 1:1', detail: '2048×2048' },
    { width: 2304, height: 1728, name: '2K 4:3', detail: '2304×1728' },
    { width: 2496, height: 1664, name: '2K 3:2', detail: '2496×1664' },
    { width: 2560, height: 1440, name: '2K 16:9', detail: '2560×1440' },
    { width: 3024, height: 1296, name: '2K 21:9', detail: '3024×1296' },
    { width: 4096, height: 4096, name: '4K 1:1', detail: '4096×4096' }
];

document.addEventListener('DOMContentLoaded', function() {
    const sizeOptionsElements = document.querySelectorAll('.size-option');
    const scaleInput = document.getElementById('scaleInput');
    const scaleValue = document.querySelector('.scale-value');
    const generateBtn = document.getElementById('generateBtn');
    const outputArea = document.getElementById('outputArea');
    const downloadSection = document.getElementById('downloadSection');
    const downloadBtn = document.getElementById('downloadBtn');

    sizeOptionsElements.forEach((option, index) => {
        if (index < sizeOptions.length) {
            option.setAttribute('data-width', sizeOptions[index].width);
            option.setAttribute('data-height', sizeOptions[index].height);
            option.querySelector('.size-name').textContent = sizeOptions[index].name;
            option.querySelector('.size-detail').textContent = sizeOptions[index].detail;
        }
        
        option.addEventListener('click', function() {
            sizeOptionsElements.forEach(opt => opt.classList.remove('active'));
            this.classList.add('active');
            selectedWidth = parseInt(this.getAttribute('data-width'));
            selectedHeight = parseInt(this.getAttribute('data-height'));
        });
    });

    const firstOption = sizeOptionsElements[1];
    if (firstOption) {
        firstOption.classList.add('active');
        sizeOptionsElements[0].classList.remove('active');
        selectedWidth = 2048;
        selectedHeight = 2048;
    }

    scaleInput.addEventListener('input', function() {
        scaleValue.textContent = this.value;
    });

    generateBtn.addEventListener('click', generateImage);

    downloadBtn.addEventListener('click', downloadImage);

    const optimizeBtn = document.getElementById('optimizeBtn');
    const optimizeHint = document.getElementById('optimizeHint');
    
    if (optimizeBtn) {
        optimizeBtn.addEventListener('click', optimizePrompt);
    }
});

async function generateImage() {
    const prompt = document.getElementById('promptInput').value.trim();
    const scaleInput = parseFloat(document.getElementById('scaleInput').value);
    const scale = scaleInput / 10;
    const usePreLlm = document.getElementById('usePreLlm').checked;

    if (!prompt) {
        showError('请输入画面描述');
        return;
    }

    const generateBtn = document.getElementById('generateBtn');
    const btnText = generateBtn.querySelector('.btn-text');
    const btnLoading = generateBtn.querySelector('.btn-loading');

    generateBtn.disabled = true;
    btnText.style.display = 'none';
    btnLoading.style.display = 'flex';

    const outputArea = document.getElementById('outputArea');
    outputArea.innerHTML = '<div class="placeholder"><div class="placeholder-icon">⏳</div><p>正在生成图像，请稍候...</p><p class="placeholder-hint">火山引擎即梦AI正在创作中，预计需要10-30秒</p></div>';

    try {
        const token = localStorage.getItem('token');
        const response = await fetch('http://localhost:5001/api/image-gen', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({
                prompt: prompt,
                width: selectedWidth,
                height: selectedHeight,
                scale: scale,
                force_single: true
            })
        });

        const data = await response.json();

        if (data.success) {
            currentImageUrl = data.image_url;
            allGeneratedImages = data.all_images || [data.image_url];
            displayImage(currentImageUrl);
            
            if (allGeneratedImages.length > 1) {
                displayMultipleImages(allGeneratedImages);
            }
            
            document.getElementById('downloadSection').style.display = 'block';
        } else {
            showError(data.message || '生成图像失败，请稍后再试');
        }
    } catch (error) {
        console.error('Error:', error);
        showError('连接服务器失败，请确保图像生成服务已启动');
    } finally {
        generateBtn.disabled = false;
        btnText.style.display = 'inline';
        btnLoading.style.display = 'none';
    }
}

function displayImage(imageUrl) {
    const outputArea = document.getElementById('outputArea');
    outputArea.innerHTML = `<img src="${imageUrl}" alt="生成的图像" style="max-width: 100%; border-radius: 8px; box-shadow: 0 4px 20px rgba(0,0,0,0.3);" />`;
}

function displayMultipleImages(imageUrls) {
    const outputArea = document.getElementById('outputArea');
    let html = '<div class="image-gallery" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 10px;">';
    
    imageUrls.forEach((url, index) => {
        html += `
            <div class="image-item" style="cursor: pointer;" onclick="selectImage('${url}')">
                <img src="${url}" alt="生成的图像 ${index + 1}" style="width: 100%; border-radius: 8px; box-shadow: 0 4px 10px rgba(0,0,0,0.2);" />
            </div>
        `;
    });
    
    html += '</div>';
    outputArea.innerHTML = html;
}

function selectImage(url) {
    currentImageUrl = url;
    displayImage(url);
}

function showError(message) {
    const outputArea = document.getElementById('outputArea');
    outputArea.innerHTML = `<div class="error-message"><p>${message}</p></div>`;
    document.getElementById('downloadSection').style.display = 'none';
}

async function downloadImage() {
    if (!currentImageUrl) return;

    try {
        const response = await fetch(currentImageUrl);
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `shigou-ai-${Date.now()}.png`;
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        document.body.removeChild(a);
    } catch (error) {
        console.error('Error downloading image:', error);
        alert('下载失败，请尝试右键保存图像');
    }
}

async function optimizePrompt() {
    const promptInput = document.getElementById('promptInput');
    const prompt = promptInput.value.trim();
    const optimizeBtn = document.getElementById('optimizeBtn');
    const optimizeHint = document.getElementById('optimizeHint');
    
    if (!prompt) {
        alert('请先输入画面描述');
        return;
    }
    
    optimizeBtn.disabled = true;
    optimizeBtn.querySelector('.optimize-text').textContent = '优化中...';
    optimizeHint.style.display = 'inline';
    
    try {
        const response = await fetch('http://localhost:5001/api/optimize-prompt', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ prompt: prompt })
        });
        
        const data = await response.json();
        
        if (data.success) {
            promptInput.value = data.optimized_prompt;
            optimizeHint.textContent = '✓ 优化完成';
            optimizeHint.style.color = '#38ef7d';
            
            setTimeout(() => {
                optimizeHint.style.display = 'none';
                optimizeHint.textContent = '正在优化...';
                optimizeHint.style.color = '#667eea';
            }, 2000);
        } else {
            alert(data.message || '优化失败，请稍后重试');
        }
    } catch (error) {
        console.error('Error:', error);
        alert('连接服务器失败，请确保服务已启动');
    } finally {
        optimizeBtn.disabled = false;
        optimizeBtn.querySelector('.optimize-text').textContent = 'AI优化提示词';
        optimizeHint.style.display = 'none';
    }
}
