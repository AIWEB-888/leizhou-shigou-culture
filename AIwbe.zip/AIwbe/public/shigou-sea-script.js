import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';

let scene, camera, renderer, controls, model;
let currentCameraIndex = 0;
let modelCameras = [];
let cameraButtons = [];
let usingModelCameras = false;

const defaultCameraPresets = [
    {
        name: '正面视角',
        position: { x: 0, y: 5, z: 15 },
        target: { x: 0, y: 2, z: 0 }
    },
    {
        name: '侧面视角',
        position: { x: 15, y: 5, z: 0 },
        target: { x: 0, y: 2, z: 0 }
    },
    {
        name: '顶部视角',
        position: { x: 0, y: 18, z: 8 },
        target: { x: 0, y: 0, z: 0 }
    },
    {
        name: '45度视角',
        position: { x: 10, y: 8, z: 10 },
        target: { x: 0, y: 2, z: 0 }
    },
    {
        name: '仰视视角',
        position: { x: 0, y: 2, z: 12 },
        target: { x: 0, y: 4, z: 0 }
    }
];

function init() {
    const container = document.getElementById('model-viewer');
    if (!container) return;

    scene = new THREE.Scene();
    scene.background = null;

    camera = new THREE.PerspectiveCamera(45, container.clientWidth / container.clientHeight, 0.1, 1000);
    camera.position.set(0, 3, 10);

    renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: 'high-performance' });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.setSize(container.clientWidth, container.clientHeight);
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.2;
    renderer.setAnimationLoop(null);
    container.appendChild(renderer.domElement);

    const ambientLight = new THREE.AmbientLight(0xffffff, 0.6);
    scene.add(ambientLight);

    const mainLight = new THREE.DirectionalLight(0xffffff, 1.5);
    mainLight.position.set(5, 10, 7);
    mainLight.castShadow = true;
    mainLight.shadow.mapSize.width = 2048;
    mainLight.shadow.mapSize.height = 2048;
    mainLight.shadow.camera.near = 0.5;
    mainLight.shadow.camera.far = 50;
    mainLight.shadow.camera.left = -10;
    mainLight.shadow.camera.right = 10;
    mainLight.shadow.camera.top = 10;
    mainLight.shadow.camera.bottom = -10;
    mainLight.shadow.bias = -0.0001;
    mainLight.shadow.radius = 4;
    scene.add(mainLight);

    const fillLight = new THREE.DirectionalLight(0xffeedd, 0.8);
    fillLight.position.set(-5, 5, 5);
    scene.add(fillLight);

    const rimLight = new THREE.DirectionalLight(0xaaccff, 1.0);
    rimLight.position.set(0, 8, -8);
    scene.add(rimLight);

    const bottomLight = new THREE.DirectionalLight(0x666688, 0.3);
    bottomLight.position.set(0, -5, 0);
    scene.add(bottomLight);

    const spotLight = new THREE.SpotLight(0xffffff, 0.5);
    spotLight.position.set(8, 12, 8);
    spotLight.angle = Math.PI / 6;
    spotLight.penumbra = 0.5;
    spotLight.decay = 2;
    spotLight.distance = 50;
    spotLight.castShadow = true;
    scene.add(spotLight);

    controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.05;
    controls.screenSpacePanning = false;
    controls.minDistance = 3;
    controls.maxDistance = 20;
    controls.zoomSpeed = 0.8;
    controls.maxPolarAngle = Math.PI / 1.8;
    controls.minPolarAngle = Math.PI / 6;

    const gridHelper = new THREE.GridHelper(15, 15, 0x666666, 0x444444);
    gridHelper.position.y = -0.01;
    scene.add(gridHelper);

    const groundPlane = new THREE.Mesh(
        new THREE.PlaneGeometry(20, 20),
        new THREE.MeshStandardMaterial({ 
            color: 0x333333,
            roughness: 0.8,
            metalness: 0.2
        })
    );
    groundPlane.rotation.x = -Math.PI / 2;
    groundPlane.position.y = -0.02;
    groundPlane.receiveShadow = true;
    scene.add(groundPlane);

    createCameraControlsUI();
    loadModel();

    window.addEventListener('resize', onWindowResize);
}

function loadModel() {
    const loader = new GLTFLoader();

    loader.load(
        'models/sigo.glb',
        function (gltf) {
            model = gltf.scene;

            const box = new THREE.Box3().setFromObject(model);
            const center = box.getCenter(new THREE.Vector3());
            const size = box.getSize(new THREE.Vector3());

            console.log('模型尺寸:', size);
            console.log('模型中心:', center);

            model.position.sub(center);
            model.position.y = size.y / 2;

            const maxDim = Math.max(size.x, size.y, size.z);
            let scale = maxDim > 0 ? 3 / maxDim : 1;
            
            if (scale < 0.01) {
                console.warn('缩放比例太小，使用固定缩放');
                scale = 1;
            }

            model.scale.set(scale, scale, scale);
            console.log('缩放比例:', scale);

            model.traverse(function (child) {
                if (child.isMesh) {
                    child.castShadow = true;
                    child.receiveShadow = true;
                    if (child.material) {
                        child.material.envMapIntensity = 0.3;
                        child.material.side = THREE.DoubleSide;
                    }
                }
            });

            scene.add(model);
            console.log('模型加载成功');

            if (gltf.cameras && gltf.cameras.length > 0) {
                console.log('模型中包含摄像机，数量:', gltf.cameras.length);
                modelCameras = gltf.cameras;
                usingModelCameras = true;
                
                gltf.cameras.forEach((cam, index) => {
                    const worldPos = new THREE.Vector3();
                    cam.getWorldPosition(worldPos);
                    console.log(`摄像机 ${index + 1} 世界位置:`, worldPos);
                    
                    const worldQuat = new THREE.Quaternion();
                    cam.getWorldQuaternion(worldQuat);
                    console.log(`摄像机 ${index + 1} 世界旋转:`, worldQuat);
                });

                updateCameraButtons();
                
                applyModelCamera(0);
            } else {
                console.log('模型中不包含摄像机，使用默认视角');
                usingModelCameras = false;
            }
        },
        function (xhr) {
            if (xhr.total > 0) {
                const percent = Math.round((xhr.loaded / xhr.total) * 100);
                console.log(`加载进度: ${percent}%`);
            }
        },
        function (error) {
            console.error('模型加载失败:', error);
        }
    );
}

function createCameraControlsUI() {
    const container = document.getElementById('model-viewer');
    if (!container) return;

    const existingControls = container.parentElement.querySelector('.camera-controls');
    if (existingControls) {
        existingControls.remove();
    }

    const controlsDiv = document.createElement('div');
    controlsDiv.className = 'camera-controls';
    controlsDiv.id = 'camera-controls-container';
    
    const title = document.createElement('div');
    title.className = 'camera-controls-title';
    title.id = 'camera-controls-title';
    title.textContent = '视角切换';
    controlsDiv.appendChild(title);

    const buttonsContainer = document.createElement('div');
    buttonsContainer.className = 'camera-buttons';
    buttonsContainer.id = 'camera-buttons-container';

    defaultCameraPresets.forEach((preset, index) => {
        const button = document.createElement('button');
        button.className = 'camera-button' + (index === 0 ? ' active' : '');
        button.textContent = preset.name;
        button.addEventListener('click', () => switchToPreset(index, button));
        buttonsContainer.appendChild(button);
        cameraButtons.push(button);
    });

    controlsDiv.appendChild(buttonsContainer);
    container.parentElement.appendChild(controlsDiv);
}

function updateCameraButtons() {
    const buttonsContainer = document.getElementById('camera-buttons-container');
    const title = document.getElementById('camera-controls-title');
    
    if (!buttonsContainer) return;

    buttonsContainer.innerHTML = '';
    cameraButtons = [];

    if (usingModelCameras && modelCameras.length > 0) {
        title.textContent = '模型摄像机视角';
        
        modelCameras.forEach((cam, index) => {
            const button = document.createElement('button');
            button.className = 'camera-button' + (index === 0 ? ' active' : '');
            button.textContent = `视角 ${index + 1}`;
            button.addEventListener('click', () => switchToModelCamera(index, button));
            buttonsContainer.appendChild(button);
            cameraButtons.push(button);
        });
    } else {
        title.textContent = '视角切换';
        
        defaultCameraPresets.forEach((preset, index) => {
            const button = document.createElement('button');
            button.className = 'camera-button' + (index === 0 ? ' active' : '');
            button.textContent = preset.name;
            button.addEventListener('click', () => switchToPreset(index, button));
            buttonsContainer.appendChild(button);
            cameraButtons.push(button);
        });
    }
}

function applyModelCamera(index) {
    if (!modelCameras[index]) return;
    
    const modelCamera = modelCameras[index];
    
    const worldPos = new THREE.Vector3();
    modelCamera.getWorldPosition(worldPos);
    
    const worldQuat = new THREE.Quaternion();
    modelCamera.getWorldQuaternion(worldQuat);
    
    const direction = new THREE.Vector3(0, 0, -1);
    direction.applyQuaternion(worldQuat);
    
    camera.position.copy(worldPos);
    camera.quaternion.copy(worldQuat);
    
    const target = new THREE.Vector3();
    target.copy(worldPos).add(direction.multiplyScalar(10));
    controls.target.copy(target);
    
    if (modelCamera.fov) {
        camera.fov = modelCamera.fov;
    }
    if (modelCamera.zoom) {
        camera.zoom = modelCamera.zoom;
    }
    camera.updateProjectionMatrix();
    
    console.log(`应用模型摄像机 ${index + 1}，位置:`, worldPos);
}

function switchToModelCamera(index, buttonElement) {
    currentCameraIndex = index;
    
    const modelCamera = modelCameras[index];
    
    const worldPos = new THREE.Vector3();
    modelCamera.getWorldPosition(worldPos);
    
    const worldQuat = new THREE.Quaternion();
    modelCamera.getWorldQuaternion(worldQuat);
    
    const startPos = camera.position.clone();
    const startQuat = camera.quaternion.clone();
    const endPos = worldPos;
    const endQuat = worldQuat;
    
    const duration = 1000;
    const startTime = Date.now();

    function animateCamera() {
        const elapsed = Date.now() - startTime;
        const progress = Math.min(elapsed / duration, 1);
        const easedProgress = 1 - Math.pow(1 - progress, 3);

        camera.position.lerpVectors(startPos, endPos, easedProgress);
        camera.quaternion.slerpQuaternions(startQuat, endQuat, easedProgress);
        
        const direction = new THREE.Vector3(0, 0, -1);
        direction.applyQuaternion(camera.quaternion);
        controls.target.copy(camera.position).add(direction.multiplyScalar(10));
        
        controls.update();

        if (progress < 1) {
            requestAnimationFrame(animateCamera);
        }
    }

    animateCamera();

    cameraButtons.forEach(btn => btn.classList.remove('active'));
    if (buttonElement) buttonElement.classList.add('active');
}

function switchToPreset(index, buttonElement) {
    currentCameraIndex = index;
    const preset = defaultCameraPresets[index];

    const startPos = camera.position.clone();
    const endPos = new THREE.Vector3(preset.position.x, preset.position.y, preset.position.z);
    const startTarget = controls.target.clone();
    const endTarget = new THREE.Vector3(preset.target.x, preset.target.y, preset.target.z);

    const duration = 1000;
    const startTime = Date.now();

    function animateCamera() {
        const elapsed = Date.now() - startTime;
        const progress = Math.min(elapsed / duration, 1);
        const easedProgress = 1 - Math.pow(1 - progress, 3);

        camera.position.lerpVectors(startPos, endPos, easedProgress);
        controls.target.lerpVectors(startTarget, endTarget, easedProgress);
        controls.update();

        if (progress < 1) {
            requestAnimationFrame(animateCamera);
        }
    }

    animateCamera();

    cameraButtons.forEach(btn => btn.classList.remove('active'));
    if (buttonElement) buttonElement.classList.add('active');
}

function onWindowResize() {
    const container = document.getElementById('model-viewer');
    if (!container) return;

    camera.aspect = container.clientWidth / container.clientHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(container.clientWidth, container.clientHeight);
}

function animate() {
    requestAnimationFrame(animate);
    
    if (controls) {
        controls.update();
    }
    
    if (renderer && scene && camera) {
        renderer.render(scene, camera);
    }
}

document.addEventListener('DOMContentLoaded', function() {
    init();
    animate();
});
