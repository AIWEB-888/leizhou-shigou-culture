import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';

let scene, camera, renderer, controls, model;
let isAutoRotate = true;
let particles;
let loadingManager, loadingProgress = 0;

const shigouData = {
    sea: {
        title: '守海石狗',
        description: `<p>守海石狗是雷州沿海地区重要的守护神，通常放置在海边、码头等位置，用于镇守海域、保佑渔民出海平安、风调雨顺。守海石狗造型威武雄壮，面朝大海，寓意守护一方海域的安宁。</p>
        <p>雷州半岛三面环海，海洋文化深厚。守海石狗体现了雷州人民对海洋的敬畏和依赖，寄托了人们对平安出海、满载而归的美好愿望。每逢渔船出海前，渔民都会祭拜守海石狗，祈求海神保佑。</p>`,
        features: ['造型威武雄壮，气势磅礴', '面朝大海，寓意守护海域', '雕刻精美，线条流畅', '通常体型较大，更显威严']
    },
    river: {
        title: '守河石狗',
        description: `<p>守河石狗主要放置在河流沿岸、渡口、桥梁等位置，用于镇守河岸、保佑渡河安全、防止水患。守河石狗通常面朝河流，寓意守护一方水域的安宁。</p>
        <p>雷州地区河流众多，水网密布。守河石狗体现了雷州人民对河流的敬畏，寄托了人们对风调雨顺、水患消除的美好愿望。每逢雨季，人们都会祭拜守河石狗，祈求河水不泛滥。</p>`,
        features: ['面朝河流，守护水域', '造型稳重，寓意镇守', '雕刻精细，表情庄严', '常置于渡口、桥梁旁']
    },
    pond: {
        title: '守塘石狗',
        description: `<p>守塘石狗主要放置在池塘、水库等位置，用于镇守水域、保佑渔业丰收、防止水患。守塘石狗通常面朝池塘，寓意守护一方水域的安宁。</p>
        <p>雷州地区池塘众多，是重要的灌溉和渔业资源。守塘石狗体现了雷州人民对水资源的重视，寄托了人们对渔业丰收、水患消除的美好愿望。每逢春耕前，人们都会祭拜守塘石狗，祈求风调雨顺。</p>`,
        features: ['面朝池塘，守护水域', '造型小巧，亲切可爱', '雕刻简洁，线条流畅', '常置于池塘边、水库旁']
    },
    well: {
        title: '守井石狗',
        description: `<p>守井石狗主要放置在井边、泉眼等位置，用于镇守水源、保佑水质清洁、防止水源污染。守井石狗通常面朝井口，寓意守护一方水源的洁净。</p>
        <p>井水是雷州人民重要的饮用水源。守井石狗体现了雷州人民对水资源的珍惜，寄托了人们对水质清洁、水源充足的美好愿望。每逢节日，人们都会祭拜守井石狗，祈求水源不枯竭。</p>`,
        features: ['面朝井口，守护水源', '造型精致，小巧玲珑', '雕刻细腻，表情温和', '常置于井边、泉眼旁']
    },
    mountain: {
        title: '守山石狗',
        description: `<p>守山石狗主要放置在山口、山腰、山顶等位置，用于镇守山林、保佑山林平安、防止山火。守山石狗通常面朝山林，寓意守护一方山林的安宁。</p>
        <p>雷州地区山林资源丰富。守山石狗体现了雷州人民对山林的敬畏，寄托了人们对山林平安、山火消除的美好愿望。每逢进山前，人们都会祭拜守山石狗，祈求山林不发生火灾。</p>`,
        features: ['面朝山林，守护山野', '造型威武，气势雄壮', '雕刻粗犷，线条刚劲', '常置于山口、山腰、山顶']
    },
    garden: {
        title: '守园石狗',
        description: `<p>守园石狗主要放置在果园、菜园等位置，用于镇守园地、保佑农作物丰收、防止虫害。守园石狗通常面朝园地，寓意守护一方园地的安宁。</p>
        <p>雷州地区农业发达，果园、菜园众多。守园石狗体现了雷州人民对农业的重视，寄托了人们对农作物丰收、虫害消除的美好愿望。每逢播种前，人们都会祭拜守园石狗，祈求五谷丰登。</p>`,
        features: ['面朝园地，守护农田', '造型可爱，憨态可掬', '雕刻简洁，线条柔和', '常置于果园、菜园边']
    },
    tomb: {
        title: '守墓石狗',
        description: `<p>守墓石狗主要放置在墓地、坟场等位置，用于镇守墓地、保佑亡灵安息、防止邪灵侵扰。守墓石狗通常面朝墓地，寓意守护一方墓地的安宁。</p>
        <p>雷州人民重视祖先崇拜。守墓石狗体现了雷州人民对祖先的敬畏，寄托了人们对亡灵安息、邪灵消除的美好愿望。每逢清明节，人们都会祭拜守墓石狗，祈求祖先保佑。</p>`,
        features: ['面朝墓地，守护亡灵', '造型庄严，表情肃穆', '雕刻精细，线条刚劲', '常置于墓地、坟场旁']
    },
    field: {
        title: '守田石狗',
        description: `<p>守田石狗主要放置在田地、农田等位置，用于镇守田地、保佑农作物丰收、防止虫害。守田石狗通常面朝田地，寓意守护一方田地的安宁。</p>
        <p>雷州地区农业发达，田地众多。守田石狗体现了雷州人民对农业的重视，寄托了人们对农作物丰收、虫害消除的美好愿望。每逢播种前，人们都会祭拜守田石狗，祈求五谷丰登。</p>`,
        features: ['面朝田地，守护农田', '造型稳重，表情温和', '雕刻简洁，线条流畅', '常置于田地、农田边']
    },
    bridge: {
        title: '守桥石狗',
        description: `<p>守桥石狗主要放置在桥头、桥尾等位置，用于镇守桥梁、保佑过桥安全、防止桥梁损坏。守桥石狗通常面朝桥梁，寓意守护一方桥梁的安宁。</p>
        <p>雷州地区桥梁众多，是重要的交通设施。守桥石狗体现了雷州人民对交通安全的重视，寄托了人们对过桥安全、桥梁坚固的美好愿望。每逢过桥前，人们都会祭拜守桥石狗，祈求平安过桥。</p>`,
        features: ['面朝桥梁，守护交通', '造型威武，气势雄壮', '雕刻精细，线条刚劲', '常置于桥头、桥尾']
    },
    road: {
        title: '守路石狗',
        description: `<p>守路石狗主要放置在路口、路边等位置，用于镇守道路、保佑行人安全、防止交通事故。守路石狗通常面朝道路，寓意守护一方道路的安宁。</p>
        <p>雷州地区道路众多，是重要的交通网络。守路石狗体现了雷州人民对交通安全的重视，寄托了人们对行人安全、道路畅通的美好愿望。每逢出行前，人们都会祭拜守路石狗，祈求一路平安。</p>`,
        features: ['面朝道路，守护交通', '造型稳重，表情温和', '雕刻简洁，线条流畅', '常置于路口、路边']
    },
    village: {
        title: '守村石狗',
        description: `<p>守村石狗主要放置在村口、村边等位置，用于镇守村庄、保佑村民平安、防止邪灵侵扰。守村石狗通常面朝村庄，寓意守护一方村庄的安宁。</p>
        <p>雷州地区村庄众多，是重要的聚居地。守村石狗体现了雷州人民对家园的重视，寄托了人们对村民平安、邪灵消除的美好愿望。每逢节日，人们都会祭拜守村石狗，祈求村庄平安。</p>`,
        features: ['面朝村庄，守护家园', '造型威武，气势雄壮', '雕刻精细，线条刚劲', '常置于村口、村边']
    },
    lane: {
        title: '守巷石狗',
        description: `<p>守巷石狗主要放置在巷口、巷边等位置，用于镇守巷道、保佑行人安全、防止邪灵侵扰。守巷石狗通常面朝巷道，寓意守护一方巷道的安宁。</p>
        <p>雷州地区巷道众多，是重要的交通网络。守巷石狗体现了雷州人民对交通安全的重视，寄托了人们对行人安全、巷道畅通的美好愿望。每逢出行前，人们都会祭拜守巷石狗，祈求一路平安。</p>`,
        features: ['面朝巷道，守护交通', '造型小巧，可爱可亲', '雕刻简洁，线条柔和', '常置于巷口、巷边']
    },
    house: {
        title: '守宅石狗',
        description: `<p>守宅石狗主要放置在宅院门口、庭院等位置，用于镇守宅院、保佑家宅平安、防止邪灵侵扰。守宅石狗通常面朝宅院，寓意守护一方宅院的安宁。</p>
        <p>雷州人民重视家庭和睦。守宅石狗体现了雷州人民对家庭的重视，寄托了人们对家宅平安、邪灵消除的美好愿望。每逢节日，人们都会祭拜守宅石狗，祈求家宅平安。</p>`,
        features: ['面朝宅院，守护家园', '造型可爱，憨态可掬', '雕刻简洁，线条柔和', '常置于宅院门口、庭院']
    },
    gate: {
        title: '守门石狗',
        description: `<p>守门石狗主要放置在门口、门边等位置，用于镇守门户、保佑出入平安、防止邪灵侵扰。守门石狗通常面朝门口，寓意守护一方门户的安宁。</p>
        <p>雷州人民重视门户安全。守门石狗体现了雷州人民对门户的重视，寄托了人们对出入平安、邪灵消除的美好愿望。每逢出入，人们都会祭拜守门石狗，祈求出入平安。</p>`,
        features: ['面朝门口，守护门户', '造型小巧，可爱可亲', '雕刻简洁，线条柔和', '常置于门口、门边']
    },
    temple: {
        title: '守庙石狗',
        description: `<p>守庙石狗主要放置在庙宇门口、庙宇周围等位置，用于镇守庙宇、保佑香客平安、防止邪灵侵扰。守庙石狗通常面朝庙宇，寓意守护一方庙宇的安宁。</p>
        <p>雷州人民重视宗教信仰。守庙石狗体现了雷州人民对宗教的重视，寄托了人们对香客平安、邪灵消除的美好愿望。每逢进庙，人们都会祭拜守庙石狗，祈求香客平安。</p>`,
        features: ['面朝庙宇，守护宗教', '造型庄严，表情肃穆', '雕刻精细，线条刚劲', '常置于庙宇门口、庙宇周围']
    },
    shrine: {
        title: '守祠石狗',
        description: `<p>守祠石狗主要放置在祠堂门口、祠堂周围等位置，用于镇守祠堂、保佑族人平安、防止邪灵侵扰。守祠石狗通常面朝祠堂，寓意守护一方祠堂的安宁。</p>
        <p>雷州人民重视祖先崇拜。守祠石狗体现了雷州人民对祖先的敬畏，寄托了人们对族人平安、邪灵消除的美好愿望。每逢祭祖，人们都会祭拜守祠石狗，祈求祖先保佑。</p>`,
        features: ['面朝祠堂，守护祖先', '造型庄严，表情肃穆', '雕刻精细，线条刚劲', '常置于祠堂门口、祠堂周围']
    }
};

function init() {
    const container = document.getElementById('model-viewer');
    if (!container) return;

    scene = new THREE.Scene();
    scene.background = null;

    camera = new THREE.PerspectiveCamera(45, container.clientWidth / container.clientHeight, 0.1, 1000);
    camera.position.set(0, 3, 10);

    renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.setSize(container.clientWidth, container.clientHeight);
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.2;
    container.appendChild(renderer.domElement);

    const ambientLight = new THREE.AmbientLight(0xffffff, 0.6);
    scene.add(ambientLight);

    const mainLight = new THREE.DirectionalLight(0xfff5e6, 1.8);
    mainLight.position.set(5, 10, 7);
    mainLight.castShadow = true;
    mainLight.shadow.mapSize.width = 2048;
    mainLight.shadow.mapSize.height = 2048;
    mainLight.shadow.camera.near = 0.5;
    mainLight.shadow.camera.far = 50;
    mainLight.shadow.camera.left = -10;
    mainLight.shadow.camera.right = 10;
    mainLight.shadow.camera.top = 10;
    mainLight.shadow.camera.bottom = -10;
    mainLight.shadow.bias = -0.0001;
    scene.add(mainLight);

    const fillLight = new THREE.DirectionalLight(0xe6f0ff, 0.8);
    fillLight.position.set(-5, 5, -5);
    scene.add(fillLight);

    const rimLight = new THREE.DirectionalLight(0xffd700, 0.5);
    rimLight.position.set(0, 5, -10);
    scene.add(rimLight);

    const bottomLight = new THREE.DirectionalLight(0xffffff, 0.3);
    bottomLight.position.set(0, -5, 0);
    scene.add(bottomLight);

    controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.05;
    controls.screenSpacePanning = false;
    controls.minDistance = 3;
    controls.maxDistance = 15;
    controls.zoomSpeed = 0.8;
    controls.maxPolarAngle = Math.PI / 2;
    controls.autoRotate = false;
    controls.autoRotateSpeed = 1.0;

    createGround();
    createParticles();

    loadModel();

    window.addEventListener('resize', onWindowResize);
}

function createGround() {
    const groundGeometry = new THREE.CircleGeometry(8, 64);
    const groundMaterial = new THREE.MeshStandardMaterial({
        color: 0x1a1a1a,
        roughness: 0.8,
        metalness: 0.2,
        transparent: true,
        opacity: 0.6
    });
    const ground = new THREE.Mesh(groundGeometry, groundMaterial);
    ground.rotation.x = -Math.PI / 2;
    ground.position.y = -0.01;
    ground.receiveShadow = true;
    scene.add(ground);

    const ringGeometry = new THREE.RingGeometry(7.5, 8, 64);
    const ringMaterial = new THREE.MeshBasicMaterial({
        color: 0xd4af37,
        side: THREE.DoubleSide,
        transparent: true,
        opacity: 0.6
    });
    const ring = new THREE.Mesh(ringGeometry, ringMaterial);
    ring.rotation.x = -Math.PI / 2;
    ring.position.y = 0;
    scene.add(ring);
}

function createParticles() {
    const particleCount = 200;
    const positions = new Float32Array(particleCount * 3);
    const colors = new Float32Array(particleCount * 3);

    for (let i = 0; i < particleCount; i++) {
        const i3 = i * 3;
        const radius = 5 + Math.random() * 10;
        const theta = Math.random() * Math.PI * 2;
        const phi = Math.random() * Math.PI;

        positions[i3] = radius * Math.sin(phi) * Math.cos(theta);
        positions[i3 + 1] = Math.random() * 8;
        positions[i3 + 2] = radius * Math.sin(phi) * Math.sin(theta);

        const goldColor = new THREE.Color(0xd4af37);
        colors[i3] = goldColor.r;
        colors[i3 + 1] = goldColor.g;
        colors[i3 + 2] = goldColor.b;
    }

    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    geometry.setAttribute('color', new THREE.BufferAttribute(colors, 3));

    const material = new THREE.PointsMaterial({
        size: 0.05,
        vertexColors: true,
        transparent: true,
        opacity: 0.6,
        blending: THREE.AdditiveBlending
    });

    particles = new THREE.Points(geometry, material);
    scene.add(particles);
}

function showLoadingProgress(progress) {
    const container = document.getElementById('model-viewer');
    let loadingDiv = document.getElementById('model-loading');
    
    if (!loadingDiv) {
        loadingDiv = document.createElement('div');
        loadingDiv.id = 'model-loading';
        loadingDiv.style.cssText = `
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            background: rgba(0, 0, 0, 0.7);
            z-index: 10;
            border-radius: 16px;
        `;
        loadingDiv.innerHTML = `
            <div style="font-size: 1.5rem; color: #d4af37; margin-bottom: 1rem;">🐕 加载中...</div>
            <div style="width: 200px; height: 4px; background: rgba(255,255,255,0.2); border-radius: 2px; overflow: hidden;">
                <div id="loading-bar" style="width: 0%; height: 100%; background: linear-gradient(90deg, #C41E3A, #d4af37); transition: width 0.3s;"></div>
            </div>
            <div id="loading-percent" style="color: #fff; margin-top: 0.5rem; font-size: 0.9rem;">0%</div>
        `;
        container.style.position = 'relative';
        container.appendChild(loadingDiv);
    }

    const loadingBar = document.getElementById('loading-bar');
    const loadingPercent = document.getElementById('loading-percent');
    if (loadingBar) loadingBar.style.width = `${progress}%`;
    if (loadingPercent) loadingPercent.textContent = `${Math.round(progress)}%`;
}

function hideLoading() {
    const loadingDiv = document.getElementById('model-loading');
    if (loadingDiv) {
        loadingDiv.style.opacity = '0';
        loadingDiv.style.transition = 'opacity 0.5s';
        setTimeout(() => loadingDiv.remove(), 500);
    }
}

function loadModel() {
    const loader = new GLTFLoader();
    
    showLoadingProgress(0);

    loader.load(
        'models/sg.glb',
        function (gltf) {
            model = gltf.scene;

            const box = new THREE.Box3().setFromObject(model);
            const center = box.getCenter(new THREE.Vector3());
            const size = box.getSize(new THREE.Vector3());

            model.position.sub(center);
            model.position.y = size.y / 2;

            const maxDim = Math.max(size.x, size.y, size.z);
            const scale = 3 / maxDim;
            model.scale.set(scale, scale, scale);

            model.traverse(function (child) {
                if (child.isMesh) {
                    child.castShadow = true;
                    child.receiveShadow = true;
                    
                    if (child.material) {
                        child.material.envMapIntensity = 1.0;
                    }
                }
            });

            scene.add(model);
            hideLoading();
        },
        function (xhr) {
            if (xhr.total > 0) {
                const percent = Math.round((xhr.loaded / xhr.total) * 100);
                showLoadingProgress(percent);
            }
        },
        function (error) {
            console.error('模型加载失败:', error);
            hideLoading();
            const container = document.getElementById('model-viewer');
            container.innerHTML = '<div style="display: flex; justify-content: center; align-items: center; height: 100%; color: #fff;"><p>模型加载失败，请刷新页面重试</p></div>';
        }
    );
}

function setCameraPosition(preset) {
    const positions = {
        front: { x: 0, y: 2, z: 8 },
        side: { x: 8, y: 2, z: 0 },
        top: { x: 0, y: 10, z: 0.1 },
        angle: { x: 5, y: 4, z: 6 },
        close: { x: 0, y: 2, z: 4 }
    };

    const pos = positions[preset];
    if (pos && camera && controls) {
        isAutoRotate = false;
        
        const startPos = { x: camera.position.x, y: camera.position.y, z: camera.position.z };
        const duration = 1000;
        const startTime = Date.now();

        function animateCamera() {
            const elapsed = Date.now() - startTime;
            const progress = Math.min(elapsed / duration, 1);
            const eased = 1 - Math.pow(1 - progress, 3);

            camera.position.x = startPos.x + (pos.x - startPos.x) * eased;
            camera.position.y = startPos.y + (pos.y - startPos.y) * eased;
            camera.position.z = startPos.z + (pos.z - startPos.z) * eased;

            controls.update();

            if (progress < 1) {
                requestAnimationFrame(animateCamera);
            }
        }

        animateCamera();
    }
}

function toggleAutoRotate() {
    isAutoRotate = !isAutoRotate;
    if (controls) {
        controls.autoRotate = isAutoRotate;
    }
    return isAutoRotate;
}

function onWindowResize() {
    const container = document.getElementById('model-viewer');
    if (!container) return;

    camera.aspect = container.clientWidth / container.clientHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(container.clientWidth, container.clientHeight);
}

function animate() {
    requestAnimationFrame(animate);
    
    if (controls) {
        controls.update();
    }

    if (particles) {
        particles.rotation.y += 0.0005;
        
        const positions = particles.geometry.attributes.position.array;
        for (let i = 0; i < positions.length; i += 3) {
            positions[i + 1] += Math.sin(Date.now() * 0.001 + i) * 0.002;
        }
        particles.geometry.attributes.position.needsUpdate = true;
    }
    
    if (renderer && scene && camera) {
        renderer.render(scene, camera);
    }
}

document.addEventListener('DOMContentLoaded', function() {
    init();
    animate();

    document.querySelectorAll('nav a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                const headerOffset = 80;
                const elementPosition = target.getBoundingClientRect().top;
                const offsetPosition = elementPosition + window.pageYOffset - headerOffset;

                window.scrollTo({
                    top: offsetPosition,
                    behavior: 'smooth'
                });
            }
        });
    });

    document.querySelectorAll('.type-item').forEach(item => {
        item.addEventListener('click', function() {
            const type = this.getAttribute('data-type');
            const data = shigouData[type];
            
            if (data) {
                document.getElementById('detail-title').textContent = data.title;
                document.getElementById('detail-description').innerHTML = data.description;
                
                const featuresList = document.getElementById('detail-features');
                featuresList.innerHTML = '';
                data.features.forEach(feature => {
                    const li = document.createElement('li');
                    li.textContent = feature;
                    featuresList.appendChild(li);
                });
                
                document.getElementById('type-detail').scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });

    const aiFloatWidget = document.getElementById('aiFloatWidget');
    const aiToggleButton = document.getElementById('aiToggleButton');
    const aiChatPanel = document.getElementById('aiChatPanel');
    const aiCloseButton = document.getElementById('aiCloseButton');
    const aiMessages = document.getElementById('aiMessages');
    const aiInput = document.getElementById('aiInput');
    const aiSendButton = document.getElementById('aiSendButton');

    if (aiToggleButton && aiChatPanel) {
        aiToggleButton.addEventListener('click', function() {
            aiChatPanel.classList.toggle('active');
        });
    }

    if (aiCloseButton && aiChatPanel) {
        aiCloseButton.addEventListener('click', function() {
            aiChatPanel.classList.remove('active');
        });
    }

    function addAiMessage(content, isUser = false) {
        const messageDiv = document.createElement('div');
        messageDiv.className = `ai-message ${isUser ? 'user-message' : ''}`;
        
        const contentDiv = document.createElement('div');
        contentDiv.className = 'ai-message-content';
        contentDiv.innerHTML = `<p>${content}</p>`;
        
        messageDiv.appendChild(contentDiv);
        aiMessages.appendChild(messageDiv);
        aiMessages.scrollTop = aiMessages.scrollHeight;
    }

    function addLoadingIndicator() {
        const loadingDiv = document.createElement('div');
        loadingDiv.className = 'ai-message';
        loadingDiv.id = 'aiLoadingIndicator';
        
        const contentDiv = document.createElement('div');
        contentDiv.className = 'ai-loading-indicator';
        
        const dotsDiv = document.createElement('div');
        dotsDiv.className = 'ai-loading-dots';
        
        for (let i = 0; i < 3; i++) {
            const dot = document.createElement('div');
            dot.className = 'ai-loading-dot';
            dotsDiv.appendChild(dot);
        }
        
        const textDiv = document.createElement('div');
        textDiv.className = 'ai-loading-text';
        textDiv.textContent = 'AI正在思考...';
        
        contentDiv.appendChild(dotsDiv);
        contentDiv.appendChild(textDiv);
        loadingDiv.appendChild(contentDiv);
        
        aiMessages.appendChild(loadingDiv);
        aiMessages.scrollTop = aiMessages.scrollHeight;
    }

    function removeLoadingIndicator() {
        const loadingIndicator = document.getElementById('aiLoadingIndicator');
        if (loadingIndicator) {
            loadingIndicator.remove();
        }
    }

    async function sendAiMessage() {
        const message = aiInput.value.trim();
        if (!message) return;
        
        addAiMessage(message, true);
        aiInput.value = '';
        aiSendButton.disabled = true;
        
        addLoadingIndicator();
        
        try {
            const response = await fetch('http://localhost:5001/api/chat', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ message: message })
            });
            
            const data = await response.json();
            
            removeLoadingIndicator();
            
            if (data.success && data.response) {
                addAiMessage(data.response, false);
            } else {
                addAiMessage(data.error || '抱歉，我遇到了一些问题。请稍后再试。', false);
            }
        } catch (error) {
            console.error('Error:', error);
            removeLoadingIndicator();
            addAiMessage('抱歉，连接服务器失败。请确保AI服务已启动。', false);
        } finally {
            aiSendButton.disabled = false;
        }
    }

    if (aiSendButton) {
        aiSendButton.addEventListener('click', sendAiMessage);
    }

    if (aiInput) {
        aiInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                sendAiMessage();
            }
        });
    }

    document.querySelectorAll('.camera-button').forEach(button => {
        button.addEventListener('click', function() {
            const preset = this.getAttribute('data-preset');
            
            if (preset === 'auto') {
                const isRotating = toggleAutoRotate();
                this.classList.toggle('active', isRotating);
            } else {
                document.querySelector('.camera-button[data-preset="auto"]')?.classList.remove('active');
                setCameraPosition(preset);
            }
            
            document.querySelectorAll('.camera-button').forEach(btn => {
                if (btn.getAttribute('data-preset') !== 'auto') {
                    btn.classList.remove('active');
                }
            });
            this.classList.add('active');
        });
    });

    const bgMusic = document.getElementById('bgMusic');
    const musicBtn = document.getElementById('musicBtn');
    const musicPlayer = document.getElementById('musicPlayer');
    const volumeSlider = document.getElementById('volumeSlider');
    const musicStatus = document.querySelector('.music-status');
    const musicIcon = document.querySelector('.music-icon');

    if (bgMusic && musicBtn) {
        bgMusic.volume = 0.3;
        
        if (musicPlayer) {
            musicPlayer.classList.add('visible');
        }

        musicBtn.addEventListener('click', function() {
            if (bgMusic.paused) {
                bgMusic.play().then(() => {
                    musicPlayer.classList.add('playing');
                    musicStatus.textContent = '暂停';
                    musicIcon.textContent = '🎶';
                }).catch(e => {
                    console.log('音频播放失败:', e);
                });
            } else {
                bgMusic.pause();
                musicPlayer.classList.remove('playing');
                musicStatus.textContent = '播放';
                musicIcon.textContent = '🎵';
            }
        });

        if (volumeSlider) {
            volumeSlider.addEventListener('input', function() {
                bgMusic.volume = this.value / 100;
            });
        }

        bgMusic.addEventListener('ended', function() {
            bgMusic.currentTime = 0;
            bgMusic.play();
        });
    }

    // 用户登录状态管理
    const userInfo = document.getElementById('userInfo');
    const loginBtn = document.getElementById('loginBtn');
    const userName = document.getElementById('userName');
    const logoutBtn = document.getElementById('logoutBtn');
    const userDropdown = document.querySelector('.user-dropdown');

    function updateLoginStatus() {
        const isLoggedIn = localStorage.getItem('isLoggedIn') === 'true';
        const user = JSON.parse(localStorage.getItem('user') || '{}');

        if (isLoggedIn && user.username) {
            if (userInfo) userInfo.style.display = 'flex';
            if (loginBtn) loginBtn.style.display = 'none';
            if (userName) userName.textContent = user.nickname || user.username;
        } else {
            if (userInfo) userInfo.style.display = 'none';
            if (loginBtn) loginBtn.style.display = 'inline-block';
        }
    }

    updateLoginStatus();

    if (userInfo) {
        userInfo.addEventListener('click', function(e) {
            e.stopPropagation();
            if (userDropdown) {
                userDropdown.classList.toggle('show');
                userInfo.classList.toggle('active');
            }
        });
    }

    document.addEventListener('click', function(e) {
        if (userDropdown && !userInfo.contains(e.target)) {
            userDropdown.classList.remove('show');
            userInfo.classList.remove('active');
        }
    });

    if (logoutBtn) {
        logoutBtn.addEventListener('click', async function(e) {
            e.preventDefault();
            
            try {
                await fetch('http://localhost:5001/api/logout', {
                    method: 'POST',
                    credentials: 'include'
                });
            } catch (error) {
                console.log('退出登录请求失败:', error);
            }
            
            localStorage.removeItem('isLoggedIn');
            localStorage.removeItem('user');
            localStorage.removeItem('token');
            updateLoginStatus();
            alert('已退出登录');
        });
    }
});

export { setCameraPosition, toggleAutoRotate };
